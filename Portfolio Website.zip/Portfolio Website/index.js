document.querySelector('.hamburger').addEventListener("click", () => {
    document.querySelector('.sidebargo').classList.toggle('sidebargo');
})